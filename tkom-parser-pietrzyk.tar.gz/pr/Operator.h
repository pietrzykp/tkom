//
// Created by paulina on 04.06.16.
//

#ifndef TKOM2_OPERATOR_H
#define TKOM2_OPERATOR_H

namespace pr {
    enum class Operator {
        Equal,
        NotEqual,
    };
}


#endif //TKOM2_OPERATOR_H
