//
// Created by paulina on 04.06.16.
//

#include "Operator.h"
